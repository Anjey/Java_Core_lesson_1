package ua.lviv.lgs;

public class HomeWork1 {
	public static void main(String[] args) {
		byte a;
		short a3;
		int a4;
		long a5;
		
		float a6;
		double a7;
		
		char a2;
		
		boolean a8;
		
		System.out.println(Byte.TYPE);
		System.out.println(Byte.MIN_VALUE);
		System.out.println(Byte.MAX_VALUE);
		
		System.out.println(Short.TYPE);
		System.out.println(Short.MIN_VALUE);
		System.out.println(Short.MAX_VALUE);
		
		System.out.println(Integer.TYPE);
		System.out.println(Integer.MIN_VALUE);
		System.out.println(Integer.MAX_VALUE);
		
		System.out.println(Long.TYPE);
		System.out.println(Long.MIN_VALUE);
		System.out.println(Long.MAX_VALUE);
		
		System.out.println(Float.TYPE);
		System.out.println(Float.MIN_VALUE);
		System.out.println(Float.MAX_VALUE);
		
		System.out.println(Double.TYPE);
		System.out.println(Double.MIN_VALUE);
		System.out.println(Double.MAX_VALUE);
		
		System.out.println(Character.TYPE);
		System.out.println((int) Character.MIN_VALUE);
        System.out.println((int) Character.MAX_VALUE);
		
	
	}
}
